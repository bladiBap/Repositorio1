package src.paint.modelo;

public abstract class Transformacion {
    protected Imagen imagen;

    public abstract void transformar();
}
