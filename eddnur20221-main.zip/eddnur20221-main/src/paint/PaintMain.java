package src.paint;

import src.paint.vista.PaintFrame;

public class PaintMain {
    public static void main(String[] args) {
        PaintFrame win = new PaintFrame();
        win.setVisible(true);
    }
}
