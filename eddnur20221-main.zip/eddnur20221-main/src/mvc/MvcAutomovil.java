package src.mvc;

import src.mvc.vista.VentanaAutomovil;

public class MvcAutomovil {
    public static void main(String[] args) {
        VentanaAutomovil v = new VentanaAutomovil();
        v.setVisible(true);
    }
}
