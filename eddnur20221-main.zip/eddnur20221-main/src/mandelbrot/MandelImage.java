package src.mandelbrot;

import src.mandelbrot.vista.VentanaMandel;

public class MandelImage {
    public static void main(String[] args) {
        VentanaMandel v = new VentanaMandel();
        v.setVisible(true);
    }
}
