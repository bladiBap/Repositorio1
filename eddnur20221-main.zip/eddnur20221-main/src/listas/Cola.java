package listas;

public class Cola {
}
