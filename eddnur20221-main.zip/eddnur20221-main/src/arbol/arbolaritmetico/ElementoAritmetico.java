package arbol.arbolaritmetico;

public class ElementoAritmetico {
}
