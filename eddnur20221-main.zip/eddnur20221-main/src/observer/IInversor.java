package src.observer;

import java.beans.PropertyChangeListener;

public interface IInversor extends PropertyChangeListener {

    public void metodo();
}
