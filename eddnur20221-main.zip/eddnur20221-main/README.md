# Bienvenidos a Programación III
Aqui todo lo necesario para la materia de Programacion III del semestre 2022/01 de la Universidad NUR de Santa Cruz de la Sierra - Bolivia


## Alumnos
En esta version de la materia hay 8 alumnos en presencial y 12 en virtual.
