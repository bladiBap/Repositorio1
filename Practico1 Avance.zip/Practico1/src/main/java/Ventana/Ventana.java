package Ventana;

import javax.swing.*;

public class Ventana extends JFrame {

    private Barra Barra;
    private Panel Panel;

    public Ventana(){

        setSize(400,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Practico1");
        //setLayout(null);
        setVisible(true);




        //init();
    }

    public static void moverDerecha() {
        Ventana ventana = new Ventana();
    }
    /*
    public void  init (){
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new BorderLayout());
        //modelo = new Automovil("Toyota",Color.BLUE,50);
        // paquete1.Panel = new PanelAutomovil(modelo);

        this.getContentPane().add(Panel,BorderLayout.CENTER);

        //menu
        JMenuBar bar = new JMenuBar();
        JMenu menu = new JMenu("AUTOMOVIL");
        bar.add(menu);
        JMenuItem item = new JMenuItem("Derecha");
        JMenuItem item2 = new JMenuItem("Izquierda");
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //menuAutomovilDerecha();
            }
        });
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //menuAutomovilIzquierda();
            }
        });
        menu.add(item);
        menu.add(item2);
        this.setJMenuBar(bar);

        this.pack();
    }

    */

}
