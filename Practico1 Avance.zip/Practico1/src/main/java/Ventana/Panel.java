package Ventana;

import javax.swing.*;

public class Panel extends JPanel {



}
