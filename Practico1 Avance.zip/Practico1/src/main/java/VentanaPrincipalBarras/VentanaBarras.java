package VentanaPrincipalBarras;

import Barras.Barras;
import Ventana.Ventana;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaBarras extends JFrame {

    private Barras modelo;
    private PanelBarras panel;

    public VentanaBarras(){
        init();
    }

    public void  init (){
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new BorderLayout());
        modelo = new Barras("Toyota",Color.BLUE,50);
        panel = new PanelBarras(modelo);

        this.getContentPane().add(panel,BorderLayout.CENTER);

        //menu
        JMenuBar bar = new JMenuBar();
        JMenu menu = new JMenu("Nuevo Numero");
        bar.add(menu);
        JMenuItem item = new JMenuItem("Nuevo Numero");

        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuAutomovilDerecha();
            }
        });
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        menu.add(item);
        menu.add(item);
        this.setJMenuBar(bar);

        this.pack();
    }

    private void menuAutomovilDerecha() {
        Ventana.moverDerecha();
        repaint();
    }


    }


