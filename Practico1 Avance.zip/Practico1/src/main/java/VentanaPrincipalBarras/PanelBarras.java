package VentanaPrincipalBarras;

import Barras.Barras;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class PanelBarras extends JPanel implements PropertyChangeListener {

    private Barras modelo;

    public PanelBarras(Barras m) {
        this.modelo = m;
        modelo.addObserver(this);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(1000,500
        );
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (modelo!= null){
            modelo.dibujar(g);
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if (evt.getPropertyName()!= "POSICION") {
            return;
        }
        repaint();
    }
}
