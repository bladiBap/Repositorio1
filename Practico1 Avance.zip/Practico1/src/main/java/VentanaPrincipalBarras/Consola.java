package VentanaPrincipalBarras;

import VentanaPrincipalBarras.VentanaBarras;

public class Consola {
    public static void main(String[] args) {

        VentanaBarras V = new VentanaBarras();
        V.setVisible(true);
    }
}
