package recursividad.hanoi.gui;

import java.awt.Graphics;

public interface IDibujo {

	public void dibujar(Graphics g);
}
