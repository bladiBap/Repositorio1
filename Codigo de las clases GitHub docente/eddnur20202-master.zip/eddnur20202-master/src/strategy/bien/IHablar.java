package strategy.bien;

public interface IHablar {

	public void hablar();
}
