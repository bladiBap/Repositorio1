package strategy.bien;

public abstract class Hablar implements IHablar{

	protected Pato sujeto;
}
