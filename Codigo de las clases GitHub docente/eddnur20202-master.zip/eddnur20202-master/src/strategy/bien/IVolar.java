package strategy.bien;

public interface IVolar {

	public void volar();
}
