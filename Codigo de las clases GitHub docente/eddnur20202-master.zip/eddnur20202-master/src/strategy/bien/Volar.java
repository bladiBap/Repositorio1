package strategy.bien;

public abstract class Volar implements IVolar {

	protected Pato sujeto;
}
