package strategy.mal;

import strategy.IPato;

public abstract class Pato implements IPato {

	protected String nombre;
}
