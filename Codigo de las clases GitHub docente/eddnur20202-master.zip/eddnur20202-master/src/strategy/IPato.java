package strategy;

public interface IPato {

	public void volar();
	public void hablar();
}
