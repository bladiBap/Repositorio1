package listas.model;

public class Mesa extends ObjetosEscritorio {

	public Mesa() {
		nombre = "Mesa";
	}
}
