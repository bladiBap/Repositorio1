package listas.model;

public class Silla extends ObjetosEscritorio{

	public Silla() {
		nombre = "Silla";
	}
}
