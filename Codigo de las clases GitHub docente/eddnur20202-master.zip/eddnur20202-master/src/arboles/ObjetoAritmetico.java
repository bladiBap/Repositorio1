package arboles;

public abstract class ObjetoAritmetico {

}
