package arboles;

public enum Operador {
	suma, resta, multiplicacion, division
}
