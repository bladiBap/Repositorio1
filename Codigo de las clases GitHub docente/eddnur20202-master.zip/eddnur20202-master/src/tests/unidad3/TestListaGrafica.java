package tests.unidad3;

import listas.gui.ListaFrame;

public class TestListaGrafica {

	public static void main(String[] args) {
		ListaFrame p = new ListaFrame();
		p.setVisible(true);
	}
}
