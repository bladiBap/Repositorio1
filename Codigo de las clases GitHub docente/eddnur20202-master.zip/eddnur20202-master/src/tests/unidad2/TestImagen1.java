package tests.unidad2;

import imagenes.FRameImagen;

public class TestImagen1 {
	public static void main(String[] args) {
		FRameImagen imgFRameImagen = new FRameImagen();
		imgFRameImagen.setVisible(true);
	}
}
