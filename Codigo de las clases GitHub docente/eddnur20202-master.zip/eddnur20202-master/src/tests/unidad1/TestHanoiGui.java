package tests.unidad1;

import recursividad.hanoi.Hanoi;
import recursividad.hanoi.gui.FrameHanoi;

public class TestHanoiGui {
	
	public Hanoi f;
	
	public static void main(String[] args) {
		
		FrameHanoi ventana = new FrameHanoi();
		ventana.setVisible(true);
	}
}
