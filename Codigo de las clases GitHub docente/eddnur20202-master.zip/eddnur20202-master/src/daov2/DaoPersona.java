package daov2;


public abstract class DaoPersona implements IDao<DtoPersona> {

}
