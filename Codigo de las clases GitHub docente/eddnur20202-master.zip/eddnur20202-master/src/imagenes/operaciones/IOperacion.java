package imagenes.operaciones;

import imagenes.Imagen;

public interface IOperacion {

	public void ejecutarCambios(Imagen img);
}
